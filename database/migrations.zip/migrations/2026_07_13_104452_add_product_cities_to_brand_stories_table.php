<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('brand_stories', function (Blueprint $table) {
            $table->json('product_cities')->nullable()->after('timeline_items');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('brand_stories', function (Blueprint $table) {
            $table->dropColumn('product_cities');
        });
    }
};
